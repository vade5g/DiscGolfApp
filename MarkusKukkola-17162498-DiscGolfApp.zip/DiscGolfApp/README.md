# DiscGolfApp
Android DiscGolf Scorecard App uses SQLite database with Room implementation.

Features: 
- User can add multiple players and keep score for them at once.
- User can query player data from previous games (Best Score, Games played etc)
